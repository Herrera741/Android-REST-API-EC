package org.csuf.cpsc411.simplehttpclient

data class Person(var firstName:String?, var lastName:String?, var ssn:String?)