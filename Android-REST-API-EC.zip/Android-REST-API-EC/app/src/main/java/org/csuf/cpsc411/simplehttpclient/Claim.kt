package org.csuf.cpsc411.simplehttpclient

data class Claim(var title: String?, var date: String?, var isSolved: Boolean?)